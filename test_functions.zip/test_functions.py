# This program has two functions. First we# define the main function.

def main():print('I have a message for you.')

message()print('Goodbye!')
# Next we define the message function.

def message():

print('I am Arthur')
print('King of the Britons.')
# Call the main function.

main()

# This program demonstrates a function that accepts
# two arguments.

def main():
print('The sum of 12 and 45 is')
show_sum(12, 45)
# The show_sum function accepts two arguments
# and displays their sum.
def show_sum(num1, num2):
result = num1 + num2print(result)
# Call the main function.

main()